import 'package:file_compressor/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('formatBytes formats values', () {
    expect(formatBytes(500), '500 B');
    expect(formatBytes(1024), '1.0 KB');
    expect(formatBytes(1024 * 1024), '1.0 MB');
  });
}
