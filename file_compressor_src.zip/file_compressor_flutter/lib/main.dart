import 'dart:io';

import 'package:archive/archive_io.dart';
import 'package:cross_file/cross_file.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseService.instance.database;
  runApp(const FileCompressorApp());
}

class FileCompressorApp extends StatelessWidget {
  const FileCompressorApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF2563EB);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ضاغط الملفات',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<OperationRecord> _history = const [];
  bool _busy = false;
  String _busyText = '';

  @override
  void initState() {
    super.initState();
    _refreshHistory();
  }

  Future<void> _refreshHistory() async {
    final rows = await DatabaseService.instance.getOperations();
    if (!mounted) return;
    setState(() => _history = rows);
  }

  void _setBusy(bool value, [String text = '']) {
    if (!mounted) return;
    setState(() {
      _busy = value;
      _busyText = text;
    });
  }

  Future<void> _compress() async {
    final picked = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.any,
      withData: false,
    );
    if (picked == null) return;

    final paths = picked.files
        .map((file) => file.path)
        .whereType<String>()
        .where((path) => path.isNotEmpty)
        .toList();

    if (paths.isEmpty) {
      _showMessage('تعذر الوصول إلى الملفات المحددة. جرّب اختيارها من ذاكرة الجهاز.');
      return;
    }

    final defaultName = paths.length == 1
        ? p.basenameWithoutExtension(paths.first)
        : 'ملفاتي_${paths.length}';
    final archiveName = await _askArchiveName(defaultName);
    if (archiveName == null) return;

    _setBusy(true, 'جارٍ ضغط ${paths.length} ملف...');
    try {
      final result = await CompressionService.instance.compressFiles(
        paths,
        archiveName,
      );

      await DatabaseService.instance.addOperation(
        OperationRecord(
          type: OperationType.compress,
          sourceName: paths.length == 1
              ? p.basename(paths.first)
              : '${paths.length} ملفات',
          outputPath: result.outputPath,
          originalSize: result.originalSize,
          outputSize: result.outputSize,
          itemCount: result.itemCount,
          createdAt: DateTime.now(),
        ),
      );
      await _refreshHistory();
      if (!mounted) return;
      await _showResult(
        title: 'تم الضغط بنجاح',
        subtitle: '${result.itemCount} ملف • ${formatBytes(result.outputSize)}',
        path: result.outputPath,
        isDirectory: false,
      );
    } catch (e) {
      _showMessage('لم يكتمل الضغط: ${friendlyError(e)}');
    } finally {
      _setBusy(false);
    }
  }

  Future<void> _extract() async {
    final picked = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      type: FileType.any,
      withData: false,
    );
    if (picked == null || picked.files.single.path == null) return;

    final archivePath = picked.files.single.path!;
    if (!CompressionService.instance.isSupportedArchive(archivePath)) {
      _showMessage('الملف غير مدعوم. استخدم ZIP أو TAR أو TGZ أو TBZ أو TXZ.');
      return;
    }

    _setBusy(true, 'جارٍ فك ضغط الملف...');
    try {
      final result = await CompressionService.instance.extractArchive(archivePath);
      await DatabaseService.instance.addOperation(
        OperationRecord(
          type: OperationType.extract,
          sourceName: p.basename(archivePath),
          outputPath: result.outputPath,
          originalSize: result.originalSize,
          outputSize: result.outputSize,
          itemCount: result.itemCount,
          createdAt: DateTime.now(),
        ),
      );
      await _refreshHistory();
      if (!mounted) return;
      await _showResult(
        title: 'تم فك الضغط بنجاح',
        subtitle: '${result.itemCount} ملف • ${formatBytes(result.outputSize)}',
        path: result.outputPath,
        isDirectory: true,
      );
    } catch (e) {
      _showMessage('لم يكتمل فك الضغط: ${friendlyError(e)}');
    } finally {
      _setBusy(false);
    }
  }

  Future<String?> _askArchiveName(String defaultName) async {
    final controller = TextEditingController(text: defaultName);
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('اسم الملف المضغوط'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textInputAction: TextInputAction.done,
          decoration: const InputDecoration(
            hintText: 'مثال: مستنداتي',
            suffixText: '.zip',
          ),
          onSubmitted: (value) {
            final name = value.trim();
            if (name.isNotEmpty) Navigator.pop(context, name);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              final name = controller.text.trim();
              if (name.isNotEmpty) Navigator.pop(context, name);
            },
            child: const Text('ابدأ الضغط'),
          ),
        ],
      ),
    );
  }

  Future<void> _showResult({
    required String title,
    required String subtitle,
    required String path,
    required bool isDirectory,
  }) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check_rounded,
                  size: 36,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 6),
              Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => _sharePath(path, isDirectory),
                  icon: const Icon(Icons.share_rounded),
                  label: Text(isDirectory ? 'مشاركة الملفات المستخرجة' : 'مشاركة ملف ZIP'),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                isDirectory
                    ? 'تم حفظ الملفات داخل مساحة التطبيق ويمكن مشاركتها من هنا.'
                    : 'يمكنك الإرسال عبر واتساب أو البريد أو الحفظ من قائمة المشاركة.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _sharePath(String path, bool isDirectory) async {
    try {
      final files = <XFile>[];
      if (isDirectory) {
        final dir = Directory(path);
        if (!await dir.exists()) throw FileSystemException('المجلد غير موجود');
        await for (final entity in dir.list(recursive: true, followLinks: false)) {
          if (entity is File) files.add(XFile(entity.path));
          if (files.length >= 100) break;
        }
      } else {
        final file = File(path);
        if (!await file.exists()) throw FileSystemException('الملف غير موجود');
        files.add(XFile(path));
      }

      if (files.isEmpty) {
        _showMessage('لا توجد ملفات متاحة للمشاركة.');
        return;
      }

      await SharePlus.instance.share(
        ShareParams(
          files: files,
          title: 'مشاركة من ضاغط الملفات',
          text: isDirectory ? 'الملفات بعد فك الضغط' : 'الملف المضغوط',
        ),
      );
    } catch (e) {
      _showMessage('تعذرت المشاركة: ${friendlyError(e)}');
    }
  }

  Future<void> _clearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('مسح السجل؟'),
        content: const Text('سيتم حذف سجل العمليات فقط، ولن تُحذف الملفات الناتجة.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('مسح'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await DatabaseService.instance.clearOperations();
    await _refreshHistory();
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Stack(
        children: [
          Scaffold(
            appBar: AppBar(
              title: const Text(
                'ضاغط الملفات',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              backgroundColor: Colors.transparent,
              actions: [
                if (_history.isNotEmpty)
                  IconButton(
                    tooltip: 'مسح السجل',
                    onPressed: _busy ? null : _clearHistory,
                    icon: const Icon(Icons.delete_sweep_outlined),
                  ),
              ],
            ),
            body: RefreshIndicator(
              onRefresh: _refreshHistory,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                children: [
                  _HeroCard(onCompress: _busy ? null : _compress, onExtract: _busy ? null : _extract),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Text(
                        'آخر العمليات',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                      const Spacer(),
                      Text(
                        '${_history.length}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (_history.isEmpty)
                    const _EmptyHistory()
                  else
                    ..._history.map(
                      (item) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _HistoryTile(
                          item: item,
                          onShare: () => _sharePath(
                            item.outputPath,
                            item.type == OperationType.extract,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (_busy)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black.withValues(alpha: 0.18),
                child: Center(
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 22),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(),
                          const SizedBox(height: 16),
                          Text(_busyText, style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          const Text('لا تغلق التطبيق حتى تنتهي العملية'),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.onCompress, required this.onExtract});

  final VoidCallback? onCompress;
  final VoidCallback? onExtract;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [colors.primary, colors.tertiary],
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: colors.primary.withValues(alpha: 0.16),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.folder_zip_rounded, color: Colors.white, size: 48),
          const SizedBox(height: 12),
          const Text(
            'اضغط ملفاتك وأرسلها بسهولة',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 6),
          Text(
            'يدعم جميع أنواع الملفات ويحفظ سجل العمليات محليًا على جهازك.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white.withValues(alpha: 0.86), height: 1.5),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: colors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: onCompress,
                  icon: const Icon(Icons.compress_rounded),
                  label: const Text('ضغط الملفات', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: BorderSide(color: Colors.white.withValues(alpha: 0.65)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: onExtract,
                  icon: const Icon(Icons.unarchive_rounded),
                  label: const Text('فك الضغط', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EmptyHistory extends StatelessWidget {
  const _EmptyHistory();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 34),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        children: [
          Icon(Icons.history_rounded, size: 42, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 10),
          const Text('لا توجد عمليات بعد', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(
            'ابدأ بضغط ملف أو فك ملف مضغوط وسيظهر هنا.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({required this.item, required this.onShare});

  final OperationRecord item;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    final isCompress = item.type == OperationType.compress;
    final color = isCompress ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.tertiary;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Icon(isCompress ? Icons.archive_rounded : Icons.unarchive_rounded, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.sourceName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  '${isCompress ? 'ضغط' : 'فك ضغط'} • ${item.itemCount} ملف • ${formatBytes(item.outputSize)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 3),
                Text(
                  formatDate(item.createdAt),
                  style: Theme.of(context).textTheme.labelSmall,
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'مشاركة',
            onPressed: onShare,
            icon: const Icon(Icons.share_outlined),
          ),
        ],
      ),
    );
  }
}

enum OperationType { compress, extract }

class OperationRecord {
  const OperationRecord({
    this.id,
    required this.type,
    required this.sourceName,
    required this.outputPath,
    required this.originalSize,
    required this.outputSize,
    required this.itemCount,
    required this.createdAt,
  });

  final int? id;
  final OperationType type;
  final String sourceName;
  final String outputPath;
  final int originalSize;
  final int outputSize;
  final int itemCount;
  final DateTime createdAt;

  Map<String, Object?> toMap() => {
        'type': type.name,
        'source_name': sourceName,
        'output_path': outputPath,
        'original_size': originalSize,
        'output_size': outputSize,
        'item_count': itemCount,
        'created_at': createdAt.millisecondsSinceEpoch,
      };

  factory OperationRecord.fromMap(Map<String, Object?> map) => OperationRecord(
        id: map['id'] as int?,
        type: (map['type'] as String) == OperationType.extract.name
            ? OperationType.extract
            : OperationType.compress,
        sourceName: map['source_name'] as String,
        outputPath: map['output_path'] as String,
        originalSize: map['original_size'] as int,
        outputSize: map['output_size'] as int,
        itemCount: map['item_count'] as int,
        createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
      );
}

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final dbPath = await getDatabasesPath();
    _database = await openDatabase(
      p.join(dbPath, 'file_compressor.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE operations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            source_name TEXT NOT NULL,
            output_path TEXT NOT NULL,
            original_size INTEGER NOT NULL,
            output_size INTEGER NOT NULL,
            item_count INTEGER NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<void> addOperation(OperationRecord item) async {
    final db = await database;
    await db.insert('operations', item.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<OperationRecord>> getOperations() async {
    final db = await database;
    final rows = await db.query('operations', orderBy: 'created_at DESC', limit: 100);
    return rows.map(OperationRecord.fromMap).toList();
  }

  Future<void> clearOperations() async {
    final db = await database;
    await db.delete('operations');
  }
}

class CompressionResult {
  const CompressionResult({
    required this.outputPath,
    required this.originalSize,
    required this.outputSize,
    required this.itemCount,
  });

  final String outputPath;
  final int originalSize;
  final int outputSize;
  final int itemCount;
}

class CompressionService {
  CompressionService._();
  static final CompressionService instance = CompressionService._();

  Future<Directory> _baseDirectory(String child) async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'FileCompressor', child));
    await dir.create(recursive: true);
    return dir;
  }

  Future<CompressionResult> compressFiles(List<String> paths, String desiredName) async {
    final existing = <File>[];
    var originalSize = 0;
    for (final path in paths) {
      final file = File(path);
      if (await file.exists()) {
        existing.add(file);
        originalSize += await file.length();
      }
    }
    if (existing.isEmpty) throw FileSystemException('لم يتم العثور على ملفات صالحة للضغط');

    final outputDir = await _baseDirectory('Compressed');
    final safeName = _safeBaseName(desiredName);
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final outputPath = p.join(outputDir.path, '${safeName}_$stamp.zip');

    final encoder = ZipFileEncoder();
    encoder.create(outputPath);
    final usedNames = <String, int>{};
    try {
      for (final file in existing) {
        final originalName = p.basename(file.path);
        final uniqueName = _uniqueFileName(originalName, usedNames);
        await encoder.addFile(file, uniqueName);
      }
    } finally {
      await encoder.close();
    }

    final outputFile = File(outputPath);
    if (!await outputFile.exists()) throw FileSystemException('تعذر إنشاء ملف ZIP');
    return CompressionResult(
      outputPath: outputPath,
      originalSize: originalSize,
      outputSize: await outputFile.length(),
      itemCount: existing.length,
    );
  }

  bool isSupportedArchive(String filePath) {
    final lower = filePath.toLowerCase();
    return lower.endsWith('.zip') ||
        lower.endsWith('.tar') ||
        lower.endsWith('.tar.gz') ||
        lower.endsWith('.tgz') ||
        lower.endsWith('.tar.bz2') ||
        lower.endsWith('.tbz') ||
        lower.endsWith('.tar.xz') ||
        lower.endsWith('.txz');
  }

  Future<CompressionResult> extractArchive(String archivePath) async {
    final archiveFile = File(archivePath);
    if (!await archiveFile.exists()) throw FileSystemException('الملف المضغوط غير موجود');

    final outputRoot = await _baseDirectory('Extracted');
    final baseName = _archiveBaseName(p.basename(archivePath));
    final outputDir = Directory(
      p.join(outputRoot.path, '${_safeBaseName(baseName)}_${DateTime.now().millisecondsSinceEpoch}'),
    );
    await outputDir.create(recursive: true);

    try {
      await extractFileToDisk(archivePath, outputDir.path);
    } catch (_) {
      if (await outputDir.exists()) await outputDir.delete(recursive: true);
      rethrow;
    }

    var fileCount = 0;
    var extractedSize = 0;
    await for (final entity in outputDir.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        fileCount++;
        extractedSize += await entity.length();
      }
    }

    return CompressionResult(
      outputPath: outputDir.path,
      originalSize: await archiveFile.length(),
      outputSize: extractedSize,
      itemCount: fileCount,
    );
  }

  String _safeBaseName(String value) {
    var cleaned = value.trim().replaceAll(RegExp(r'\.zip$', caseSensitive: false), '');
    cleaned = cleaned.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (cleaned.isEmpty) cleaned = 'archive';
    return cleaned.length > 60 ? cleaned.substring(0, 60) : cleaned;
  }

  String _uniqueFileName(String name, Map<String, int> used) {
    final count = used.update(name, (value) => value + 1, ifAbsent: () => 1);
    if (count == 1) return name;
    final ext = p.extension(name);
    final base = p.basenameWithoutExtension(name);
    return '${base}_$count$ext';
  }

  String _archiveBaseName(String name) {
    final lower = name.toLowerCase();
    const endings = ['.tar.gz', '.tar.bz2', '.tar.xz', '.tgz', '.tbz', '.txz', '.zip', '.tar'];
    for (final ending in endings) {
      if (lower.endsWith(ending)) return name.substring(0, name.length - ending.length);
    }
    return p.basenameWithoutExtension(name);
  }
}

String friendlyError(Object error) {
  final raw = error.toString().replaceFirst('Exception: ', '').replaceFirst('FileSystemException: ', '');
  if (raw.length > 140) return '${raw.substring(0, 140)}…';
  return raw;
}

String formatBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  final kb = bytes / 1024;
  if (kb < 1024) return '${kb.toStringAsFixed(kb >= 100 ? 0 : 1)} KB';
  final mb = kb / 1024;
  if (mb < 1024) return '${mb.toStringAsFixed(mb >= 100 ? 0 : 1)} MB';
  final gb = mb / 1024;
  return '${gb.toStringAsFixed(gb >= 100 ? 0 : 1)} GB';
}

String formatDate(DateTime date) {
  String two(int value) => value.toString().padLeft(2, '0');
  return '${two(date.day)}/${two(date.month)}/${date.year} • ${two(date.hour)}:${two(date.minute)}';
}
